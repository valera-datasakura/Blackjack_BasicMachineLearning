﻿using UnityEngine;
using System;
using System.Collections;
using System.Xml;
using System.Text;
using System.IO;

public class RecordManager : MonoBehaviour
{
    static RecordManager sInstance;
    public static RecordManager Instance
    {
        get
        {
            if (sInstance == null)
            {
                GameObject newObj = new GameObject("_RecordManager");
                sInstance = newObj.AddComponent<RecordManager>();
            }

            return sInstance;
        }
    }

    int account = 0;

    int firstAccount = 1000;
    int expirationHour = 24;

    //________________________________________Initialize________________________________________
    void Awake()
    {
        DontDestroyOnLoad(gameObject);
        
        load();
    }

    public int AmountOfAccount
    {
        get
        {
            account = PlayerPrefs.GetInt("Account");
            return account;
        }
        set
        {
            account = value;
           
        }
    }
    public bool IsCharging
    {
        get
        {
            return PlayerPrefs.HasKey("ExpirationStartOn");
        }
    }

    public void ResetAccount()
    {
        PlayerPrefs.DeleteKey("ExpirationStartOn");
        account = firstAccount;
        PlayerPrefs.SetInt("Account", firstAccount);
    }
    public void SetAccount(int num)
    {
        account = num;
    }
    
    void load()
    {
        if (PlayerPrefs.HasKey("FirstAccountDone"))
        {
            account = PlayerPrefs.GetInt("Account");
        }
        else
        {
            account = firstAccount;
            PlayerPrefs.SetInt("Account", account);
            PlayerPrefs.SetInt("FirstAccountDone", 1);
        }
    }
}
