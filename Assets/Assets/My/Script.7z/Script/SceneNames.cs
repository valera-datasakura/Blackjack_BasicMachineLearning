﻿public class SceneNames {

    public const int calculate = 3;
}
