﻿using UnityEngine;
using System.Collections;

public class Chip : MonoBehaviour {

    public int value;
	
	public int Value
    {
        get
        {
            return this.value;
        }
    }
}
